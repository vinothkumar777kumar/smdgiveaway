var registerEvents = {

    slick: function() {
        $('.your-class').slick({
            infinite: false,
            slidesToShow: 3,
            slidesToScroll: 3
        });
    }


};

$(document).ready(function() {
    window.registerEvents = registerEvents;
});