import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ComponentModule } from './component/component.module';
import { BasiclayoutModule } from './layout/basiclayout/basiclayout.module';
import { BasiclayoutComponent } from './layout/basiclayout/basiclayout.component';
import { HowtoplayComponent } from './pages/howtoplay/howtoplay.component';
import { BlogComponent } from './pages/blog/blog.component';
import { ActivecompetitionComponent } from './pages/activecompetition/activecompetition.component';
import { LiveDrawsComponent } from './pages/live-draws/live-draws.component';
import { WinnersPodiumComponent } from './pages/winners-podium/winners-podium.component';







@NgModule({
  declarations: [
    AppComponent,
    BasiclayoutComponent,
    HowtoplayComponent,
    BlogComponent,
    ActivecompetitionComponent,
    LiveDrawsComponent,
    WinnersPodiumComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BasiclayoutModule,
    ComponentModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
