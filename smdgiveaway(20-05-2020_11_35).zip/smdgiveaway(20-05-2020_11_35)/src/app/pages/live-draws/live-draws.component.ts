import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-draws',
  templateUrl: './live-draws.component.html',
  styleUrls: ['./live-draws.component.css']
})
export class LiveDrawsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
