import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activecompetition',
  templateUrl: './activecompetition.component.html',
  styleUrls: ['./activecompetition.component.css']
})
export class ActivecompetitionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
