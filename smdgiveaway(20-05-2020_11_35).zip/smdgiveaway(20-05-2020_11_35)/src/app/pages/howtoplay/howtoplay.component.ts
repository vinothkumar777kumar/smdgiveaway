import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-howtoplay',
  templateUrl: './howtoplay.component.html',
  styleUrls: ['./howtoplay.component.css']
})
export class HowtoplayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
