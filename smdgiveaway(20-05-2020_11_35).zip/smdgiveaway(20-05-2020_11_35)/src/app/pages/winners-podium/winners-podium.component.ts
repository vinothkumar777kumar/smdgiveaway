import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-winners-podium',
  templateUrl: './winners-podium.component.html',
  styleUrls: ['./winners-podium.component.css']
})
export class WinnersPodiumComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
