import { NgModule } from '@angular/core';
import { Routes, RouterModule,RouterLink } from '@angular/router';
import { BasiclayoutComponent } from './layout/basiclayout/basiclayout.component';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';

const routes: Routes = [
  { path: '', redirectTo: 'Home', pathMatch: 'full' },
  {path:'',component:BasiclayoutComponent,children:[
    {
      path: '',
      loadChildren: './layout/basiclayout/basiclayout.module#BasiclayoutModule'
    }
  ]},
];

@NgModule({
  imports: [CommonModule,BrowserModule,RouterModule.forRoot(routes,{useHash:true})],
  exports: [RouterModule,RouterLink]
})
export class AppRoutingModule { }
