import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from 'src/app/pages/home/home.component';
import { BasicLayoutRoutes } from './basiclayout-routing.module';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from 'src/app/pages/login/login.component';
import { RegisterComponent } from 'src/app/pages/register/register.component';



@NgModule({
  declarations: [HomeComponent,LoginComponent,RegisterComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(BasicLayoutRoutes),
    FormsModule,
    ReactiveFormsModule,
    NgbModule
  ]
})
export class BasiclayoutModule { }
