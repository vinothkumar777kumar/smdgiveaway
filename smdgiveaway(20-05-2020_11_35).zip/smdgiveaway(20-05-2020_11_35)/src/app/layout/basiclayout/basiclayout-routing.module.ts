import { Routes } from '@angular/router';
import { HomeComponent } from 'src/app/pages/home/home.component';
import { LoginComponent } from 'src/app/pages/login/login.component';
import { RegisterComponent } from 'src/app/pages/register/register.component';
import { HowtoplayComponent } from 'src/app/pages/howtoplay/howtoplay.component';
import { BlogComponent } from 'src/app/pages/blog/blog.component';
import { ActivecompetitionComponent } from 'src/app/pages/activecompetition/activecompetition.component';
import { LiveDrawsComponent } from 'src/app/pages/live-draws/live-draws.component';
import { WinnersPodiumComponent } from 'src/app/pages/winners-podium/winners-podium.component';


export const BasicLayoutRoutes: Routes = [
    { path: 'Home', component: HomeComponent },
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'how_to_play', component: HowtoplayComponent },
    { path: 'blog', component: BlogComponent },
    { path: 'active-competitions', component: ActivecompetitionComponent},
    { path: 'live-draws', component: LiveDrawsComponent},
    { path: 'winners-podium', component: WinnersPodiumComponent},
    
    
];
