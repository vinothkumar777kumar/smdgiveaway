import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basiclayout',
  templateUrl: './basiclayout.component.html',
  styleUrls: ['./basiclayout.component.css']
})
export class BasiclayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
